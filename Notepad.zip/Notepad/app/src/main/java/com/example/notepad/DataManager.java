package com.example.notepad;

import android.provider.ContactsContract;

import java.util.ArrayList;

public class DataManager{

    public static ArrayList<Notes> notes = new ArrayList<>();

    public Notes createNote(String title, String content){
        Notes note = new Notes(title, content);
        notes.add(note);

        return note;
    }
}
