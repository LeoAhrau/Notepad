package com.example.notepad;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class NotesActivity extends AppCompatActivity {

    EditText titleInput;
    EditText contentInput;
    ArrayAdapter<Notes> adapter;

    DataManager dataManager = new DataManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        titleInput = findViewById(R.id.et_title_input);
        contentInput = findViewById(R.id.et_content_input);
        Button saveNote = findViewById(R.id.btn_save_note);
        Button clearNote = findViewById(R.id.btn_clear_note);
        Button cancelNote = findViewById(R.id.btn_cancel);
        TextView test = findViewById(R.id.tv_test);

        String title = titleInput.getText().toString();
        String content = contentInput.getText().toString();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, DataManager.notes);

        File file = new File(NotesActivity.this.getFilesDir(), "text");
        saveNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!titleInput.getText().toString().isEmpty()){
                    if(!contentInput.getText().toString().isEmpty()){

                        if(!file.exists()){
                            file.mkdir();
                        }
                        try {


                            File notefile = new File(file, title +".txt");
                            FileWriter writer = new FileWriter(notefile);
                            writer.append(title);

                            File notefile2 = new File(file, title+"2.txt");
                            FileWriter writer2 = new FileWriter(notefile2);
                            writer.append(content);

                            writer.flush();
                            writer.close();
                            Toast.makeText(NotesActivity.this, "note saved!", Toast.LENGTH_SHORT).show();
                        } catch (IOException e) {

                        }
                    }
                }

            }
        });



        clearNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    File readFile = new File(file, title + ".txt");
                    Scanner scanner = new Scanner(readFile);
                    test.setText(scanner.nextLine());


                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        cancelNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NotesActivity.this, MainActivity.class);
                startActivity(intent);

            }
        });

    }

}
